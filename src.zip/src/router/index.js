import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import store from "../store/index";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/about",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/About.vue"),
  },
  {
    path: "/loginNew",
    name: "Login",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/Login.vue"),
  },
  // {
  //   path: "/home",
  //   name: "Home",
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () =>
  //     import(/* webpackChunkName: "about" */ "../views/Home.vue"),
  // },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes: routes,
});

router.beforeEach((to, from, next) => {
  if (to.path === "/") {
    //
    if (store.state.loggedInUser) {
      next();
    } else {
      next();
    }
  } else {
    if (!store.state.loggedInUser) {
      localStorage.clear();
      router.push("/").catch(() => {});
      next();
    } else {
      next();
    }
  }
});
// router.beforeEach((to, from, next) => {
//   const storageCheck = store.state.loggedInUser;

//   // CHECK IF THE ROUTES HAVE AUTHENTICATION
//   if (to.matched.some((record) => record.meta.requiresAuth)) {
//     //CHECK IF THE USER IS AUTHENTICATED
//     if (Object.keys(storageCheck).length != 0) router.replace(`/login`);
//     // USER IS NOT AUTHENTICATED
//     else router.push(`/login`);

//     next();
//   } else {
//     if (storageCheck) {
//       localStorage.clear();
//       next();
//     } else next();
//   }
// });

export default router;
