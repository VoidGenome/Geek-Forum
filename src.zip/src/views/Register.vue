<template>
  <div>
    <!-- <v-dialog v-model="registerDialog" width="450px" height="450px"> -->
    <v-container class="d-flex justify-center">
      <v-card width="450px" height="470px">
        <v-card-title
          style="font-style: white; font-family: 'Brush Script MT', Cursive"
          >Register Account<v-spacer />
          <!-- <v-icon @click="registerDialog = false"
            >mdi-close</v-icon
          > -->
        </v-card-title>
        <v-divider class="mt-n2 mb-2" />
        <v-card-text>
          <v-text-field
            outlined
            dense
            label="Username"
            v-model="username"
          ></v-text-field>
          <v-text-field
            type="password"
            outlined
            v-model="password"
            dense
            label="Password"
          ></v-text-field>
          <!-- <v-text-field
            type="password"
            outlined
            dense

            label="Confirm Password"
          ></v-text-field> -->
          <v-text-field
            label="Email"
            dense
            outlined
            v-model="email"
          ></v-text-field>
          <v-text-field
            :rules="[ageRule.age]"
            v-model="age"
            label="Age"
            dense
            type="number"
            outlined
          ></v-text-field>
          <!-- <v-radio-group v-model="eula"> -->
          <v-checkbox
            v-model="eula"
            class="labelFont mt-n3"
            value="agree"
            label="By clicking this button , you agree to the terms and conditions"
          ></v-checkbox>
          <!-- </v-radio-group> -->

          <br />
          <v-row>
            <v-col cols="6">
              <!-- <v-btn
                block
                class="fontStyle"
                color="error"
                @click="cancelRegister()"
                dense
                >Cancel</v-btn
              > -->
            </v-col>
            <v-col cols="6"
              ><v-btn
                class="fontStyle"
                block
                :disabled="!eula"
                color="success"
                @click="registerAccount()"
                dense
                >Save</v-btn
              ></v-col
            >
          </v-row>
        </v-card-text>
      </v-card>
    </v-container>
    <!-- </v-dialog> -->
  </div>
</template>
<script>
import axios from "axios";
export default {
  data: () => ({
    age: "",
    registerDialog: false,
    username: "",
    password: "",
    email: "",
    eula: "",
    rules: {
      required: (value) => !!value || "Required.",
      min: (v) => v.length >= 8 || "Min 8 characters",
      emailMatch: () => `The passwords you entered don't match`,
    },
    ageRule: {
      age: (v) =>
        v.length < 18 || "Age 18 above are allowed to create an account",
    },
  }),
  watch: {},
  methods: {
    openDialog() {
      this.registerDialog = true;
    },
    async registerAccount() {
      let obj = {
        Username: this.username,
        Password: this.password,
        EmailAddress: this.email,
        Age: this.age,
      };

      await axios
        .post("http://localhost:8888/api/addAccount", { data: obj })
        .then((res) => console.log(res.data))
        .catch((err) => console.log(err));

      // this.cancelRegister();
      this.$toast.success("Your Account has been Registered!");
      this.$emit("goToLogin", 1);
      this.username = "";
      this.password = "";
      this.email = "";
      this.age = "";
    },
    cancelRegister() {
      this.username = "";
      this.password = "";
      this.email = "";
      this.age = "";
      this.registerDialog = false;
    },
    eulaFunction() {
      if (this.eula == "agree") {
        this.eula = "";
      } else {
        this.eula = "agree";
      }
      this.$forceUpdate();
      console.log(this.eula);
    },
  },
};
</script>
<style scoped>
.labelFont >>> label {
  font-size: 12px;
}
.fontStyle {
  /* font-style: white; */
  font-family: "Brush Script MT", Cursive;
}
.v-text-field >>> label {
  font-family: "Brush Script MT", Cursive;
}
</style>
