<template>
  <div>
    <v-card height="800px">
      <div style="text-align: center">
        <v-progress-linear indeterminate color="green"></v-progress-linear>
      </div>
      <v-card-text>
        <span>Forum</span>
      </v-card-text>
    </v-card>
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
