<template>
  <div>
    <v-container class="d-flex justify-center" style="margin-top: 10vh">
      <v-hover v-slot="{ isHovering, props }">
        <v-card
          v-bind="props"
          width="500px"
          height="270px"
          :elevation="isHovering ? 24 : 6"
        >
          <v-card-title
            class="justify-center white--text"
            style="
              background: grey;
              font-style: white;
              font-family: 'Brush Script MT', Cursive;
            "
            >Geek Forum
          </v-card-title>
          <v-divider class="mb-n3"></v-divider>
          <v-card-text>
            <v-row>
              <v-col cols="5">
                <v-sheet
                  ><v-img
                    src="../../public/wiggle-peter-griffin.gif"
                    width="150px"
                    height="150px"
                  ></v-img
                ></v-sheet>
              </v-col>

              <v-col cols="7">
                <!-- <div class='pt-4 mr-n3 pb-3' v-bind:style="{ backgroundColor: color}"> -->
                <v-card
                  class="pt-4 ml-2 mr-n6 pb-3"
                  elevation="4"
                  color="#CFD8DC"
                >
                  <v-text-field
                    label="Username"
                    v-model="userName"
                    dense
                    outlined
                    class="shrink ml-4"
                    style="width: 230px"
                  ></v-text-field>

                  <v-text-field
                    class="shrink ml-4"
                    style="width: 230px"
                    label="Password"
                    v-model="passWord"
                    dense
                    outlined
                    type="password"
                    @keyup.enter="login()"
                  ></v-text-field>
                  <v-row>
                    <v-col cols="6">
                      <!-- <v-chip
                      label
                      @click="openRegisterDialog()"
                      role="button"
                      class="ml-3 fontStyle"
                      >Register <RegisterDialog ref="register"
                    /></v-chip> -->
                    </v-col>
                    <v-col cols="6">
                      <v-btn
                        shaped
                        width="100px"
                        class="fontStyle"
                        @click="login()"
                        >enter</v-btn
                      >
                    </v-col>
                  </v-row>
                  <!-- </div> -->
                </v-card>
              </v-col>
            </v-row>
          </v-card-text>
        </v-card>
      </v-hover>
    </v-container>
    <v-overlay
      v-model="loading"
      width="100px"
      elevation="0"
      persistent
      no-click-animation
    >
      <div class="text-center" style="overflow: hidden !important">
        <v-progress-circular
          :size="100"
          indeterminate
          :width="10"
          color="green"
        ></v-progress-circular>
      </div>
    </v-overlay>
  </div>
</template>
<script>
import { mapActions } from "vuex";
// import RegisterDialog from "./Register.vue";
import axios from "axios";
export default {
  components: {
    // RegisterDialog,
  },
  data: () => ({
    userName: "",
    passWord: "",
    color: "#673AB7",
    elevate: 3,
    loading: false,
  }),
  methods: {
    ...mapActions(["STORE_USER"]),

    async login() {
      await axios
        .get(
          `http://localhost:8888/api/checkAccount/${this.userName}/${this.passWord}`
        )
        .then((res) => {
          this.loading = true;

          if (res.data.length) {
            console.log(res.data);
            let obj = {
              username: this.userName,
              password: this.passWord,
            };
            setTimeout(() => {
              this.STORE_USER(obj);
              this.$router.push("/");
              window.open(`http://${window.location.host}/`, "_self");
            }, 1500);
            this.loading = false;
            return this.$toast.success(`Welcome  ${this.userName}`);
          } else {
            this.loading = false;
            return this.$toast.info(
              `Account ${this.userName} is not registered`
            );
          }
        })
        .catch((err) => console.log(err));
      // let obj = {
      //   username: this.userName,
      //   password: this.passWord,
      // };
      // if (this.userName == "admin" && this.passWord == "admin") {
      //   this.STORE_USER(obj);
      //   this.$router.push("/");
      //   window.open(`http://${window.location.host}/`, "_self");
      // } else {
      //   alert("Invalid username and password");
      //   // this.$router.push("/");

      this.userName = "";
      this.passWord = "";
      // }
    },
    openRegisterDialog() {
      this.$refs.register.openDialog();
    },
  },
};
</script>
<style scoped>
.v-text-field >>> label {
  font-style: white;
  font-family: "Brush Script MT", Cursive;
}
.fontStyle {
  /* font-style: white; */
  font-family: "Brush Script MT", Cursive;
}
</style>
