<template>
  <div>
    <v-card height="800px">
      <div style="text-align: center">
        <v-progress-linear indeterminate color="green"></v-progress-linear>
      </div>
      <v-card-text>
        <!-- <v-card elevation="2" height="400px">
          <v-row>
            <v-col cols="6">
              <v-img
                class="mt-2"
                src="../../../public/puck.jpg"
                height="360px"
              ></v-img>
            </v-col>
            <v-col cols="6">
              <v-sheet height="350px" width="720px" color="grey">
                <v-col cols="12">
                  <span style="font-family: 'Brush Script MT', Cursive"
                    >5 minutes lothars</span
                  >
                  <small style="color: #1976d2"> posted 5 mins ago..</small>
                  <br />
                  <br />
                  <br />
                  <br />
                  <v-row>
                    <v-col cols="2">
                      <span>Comments</span>
                    </v-col>
                    <v-col cols="2">
                      <span>Write a comment</span>
                    </v-col>
                    <v-col cols="7">
                      <v-text-field
                        clearable
                        class="textHeight"
                        outlined
                        dense
                      ></v-text-field>
                    </v-col>
                  </v-row>
                  <br />
                  <v-card-text>
                    <v-sheet outlined color="white" height="100px">
                      <span>Spammer</span>
                      <br />
                      <span>Wala yan</span>
                    </v-sheet>
                  </v-card-text>
                </v-col>
              </v-sheet>
            </v-col>
          </v-row>
        </v-card> -->
      </v-card-text>
    </v-card>
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
.textHeight >>> {
  height: 5px !important;
}
</style>
