<template>
  <div>
    <v-dialog
      hide-overlay
      v-model="favoritesDialog"
      height="700px"
      width="700px"
      no-click-animation
      persistent
    >
      <v-card height="700px" width="700px">
        <v-card-title
          ><v-spacer /><v-icon @click="favoritesDialog = false"
            >mdi-close-outline</v-icon
          ></v-card-title
        >
      </v-card>
    </v-dialog>
  </div>
</template>
<script>
export default {
  data: () => ({
    favoritesDialog: false,
  }),
  methods: {
    openFavoritesDialog() {
      this.favoritesDialog = true;
    },
  },
};
</script>
<style scoped></style>
