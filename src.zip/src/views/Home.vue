<template>
  <div class="home">
    <v-row>
      <v-col cols="1"></v-col>
      <v-col cols="10">
        <!-- <v-card class="ml-2" style="background: #c44049"> -->
        <v-toolbar dark class="ml-2 mb-n4" style="background: #c44049">
          <v-tabs v-model="tab" class="mt-n3">
            <v-tab href="#tab-1" class="enlarge">Hot Topics!</v-tab>
            <v-tab href="#tab-2" class="enlarge">Articles</v-tab>
            <v-tab href="#tab-3" class="enlarge">Forums</v-tab>
          </v-tabs>
        </v-toolbar>

        <!-- </v-card> -->
        <div>
          <v-tabs-items class="ml-2" v-model="tab">
            <v-tab-item :value="'tab-1'" style="height: auto">
              <HotTopics ref="hotTopics" />
            </v-tab-item>
            <v-tab-item :value="'tab-2'" style="height: auto">
              <Article ref="article" />
            </v-tab-item>
            <v-tab-item :value="'tab-3'" style="height: auto">
              <Forums ref="forums" />
            </v-tab-item>
          </v-tabs-items>
        </div>
      </v-col>

      <!-- <v-col cols="6">
        <v-card style="background: #c44049" height="47px" class="mr-2"> -->
      <!-- <v-tabs>
            <v-tab>Mobile</v-tab>
            <v-tab>Console</v-tab>
            <v-tab>PC</v-tab>
          </v-tabs> -->

      <!-- <div style="display: flex; justify-content: flex-end">
            <div>
              <v-icon
                cols="2"
                class="enlarge mt-2"
                color="white"
                @click="openMessageDialog()"
                >mdi-message
              </v-icon>
              <Message ref="messageRef" />
            </div>

            <v-icon class="enlarge mt-2 ml-5" color="white">mdi-cog</v-icon>
            <v-icon class="enlarge mt-2 ml-4 mr-4" color="white"
              >mdi-help-circle-outline</v-icon
            >
          </div>
        </v-card>
        <PersonalPage />
      </v-col> -->
    </v-row>

    <!-- <HelloWorld msg="Welcome to Your Vue.js App" /> -->
    <!-- <FrontView /> -->
    <!-- <v-container right absolute fluid class='pa-0'> -->

    <!-- </v-container> -->
    <!-- <v-btn small fab right absolute><v-icon>mdi-message</v-icon></v-btn> -->
    <!-- <v-row>
      <v-col cols='10'></v-col>
       <v-col cols='2'>
      
      <v-btn right fab><v-icon>mdi-message</v-icon></v-btn>
      <v-btn right fab><v-icon>mdi-message</v-icon></v-btn>
      <v-btn  right fab><v-icon>mdi-message</v-icon></v-btn>
      <v-btn right  fab><v-icon>mdi-dots-horizontal</v-icon></v-btn>
   
     
   </v-col>
   
   
   
   </v-row> -->
    <div class="text-right" v-if="userData">
      <Message ref="messageRef" />
      <Favorites ref="favorites" />
      <v-speed-dial
        v-model="fab"
        absolute
        bottom
        right
        transition="slide-y-reverse-transition"
      >
        <template class="text-right" v-slot:activator>
          <v-btn v-model="fab" color="blue darken-2" dark fab right>
            <v-icon v-if="fab"> mdi-close </v-icon>
            <v-icon v-else> mdi-dots-horizontal </v-icon>
          </v-btn>
        </template>
        <v-btn fab @click="openMessageDialog()" dark small right>
          <v-tooltip color="info" left>
            <template v-slot:activator="{ on, attrs }">
              <v-icon v-bind="attrs" v-on="on">mdi-message-outline</v-icon>
            </template>
            <span>Chat</span>
          </v-tooltip>
        </v-btn>
        <v-btn fab dark small right @click="openFavoritesDialog()">
          <v-tooltip color="red lighten-2" left>
            <template v-slot:activator="{ on, attrs }">
              <v-icon v-bind="attrs" v-on="on">mdi-heart-outline</v-icon>
            </template>
            <span>Favorites</span>
          </v-tooltip>
        </v-btn>
        <v-btn fab dark small color="red" right>
          <v-icon>mdi-delete</v-icon>
        </v-btn>
      </v-speed-dial>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from "@/components/HelloWorld.vue";
// import FrontView from "../components/FrontView.vue";
import Message from "./message/Message.vue";
// import PersonalPage from "./personalPage/PersonalPage.vue";
import HotTopics from "./HotTopics/HotTopics.vue";
import Forums from "./Forum/Forum.vue";
import Article from "./Article/Article.vue";
import store from "@/store";
import Favorites from "./Favorites.vue";

export default {
  name: "Home",
  data: () => ({
    tab: null,
    hidden: null,
    fab: false,
    userData: store.state.loggedInUser,
  }),
  components: {
    // HelloWorld,
    // FrontView,
    Message,
    Article,
    // PersonalPage,
    HotTopics,
    Forums,
    Favorites,
  },
  methods: {
    openMessageDialog() {
      this.$refs.messageRef.openMessageDialog();
    },
    openFavoritesDialog() {
      this.$refs.favorites.openFavoritesDialog();
    },
  },
};
</script>
<style scoped>
.enlarge {
  font-family: "Brush Script MT", Cursive;
}
.enlarge:hover,
.enlarge:hover + p {
  transform: scale(1.2);
}
/* . */
</style>
