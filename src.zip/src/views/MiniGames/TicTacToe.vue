<template>
  <div>
    <v-dialog v-model="tictacDialog" width="300px" height="250px">
      <v-card width="300px" height="300px">
        <v-card-text>
          <v-simple-table
            class="table"
            style="border-collapse: collapse !important"
          >
            <tbody>
              <tr>
                <td @click="clickHere(1)">
                  <v-icon v-if="exes1">{{ userIcon }}</v-icon>
                </td>
                <td @click="clickHere(2)">
                  <v-icon v-if="exes2">{{ userIcon }}</v-icon>
                </td>
                <td @click="clickHere(3)">
                  <v-icon v-if="exes3">{{ userIcon }}</v-icon>
                </td>
              </tr>
              <tr>
                <td @click="clickHere(4)">
                  <v-icon v-if="exes4">{{ userIcon }}</v-icon>
                </td>
                <td @click="clickHere(5)">
                  <v-icon v-if="exes5">{{ userIcon }}</v-icon>
                </td>
                <td @click="clickHere(6)">
                  <v-icon v-if="exes6">{{ userIcon }}</v-icon>
                </td>
              </tr>
              <tr>
                <td @click="clickHere(7)">
                  <v-icon v-if="exes7">{{ userIcon }}</v-icon>
                </td>
                <td @click="clickHere(8)">
                  <v-icon v-if="exes8">{{ userIcon }}</v-icon>
                </td>
                <td @click="clickHere(9)">
                  <v-icon v-if="exes9">{{ userIcon }}</v-icon>
                </td>
              </tr>
            </tbody>
          </v-simple-table>
          <br />
          <v-row v-if="yourToken == ''">
            <v-col cols="5">
              <span style="font-weight: bold" class="align-right"
                >Pick your side</span
              >
            </v-col>
            <v-col cols="3">
              <v-btn outlined text @click="tokenPicked('X')" elevation="0"
                >X</v-btn
              >
            </v-col>
            <v-col cols="3">
              <v-btn outlined text @click="tokenPicked('O')" elevation="0"
                >O</v-btn
              >
            </v-col>
          </v-row>
          <span
            :style="
              timerMin == 0 && timerSec <= 20
                ? 'color:#E53935;font-weight:bold;'
                : 'font-weight:bold;'
            "
            >{{ `${timerMin}:${timerSec}` }}</span
          >
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>
<script>
export default {
  data: () => ({
    tictacDialog: false,
    yourToken: "",
    exes1: "",
    exes2: "",
    exes3: "",
    exes4: "",
    exes5: "",
    exes6: "",
    exes7: "",
    exes8: "",
    exes9: "",
    computerToken: "",
    timerMin: 2,
    timerSec: 59,
    userIcon: "",
    yourListedNumber: [],
    computerListedNumber: [],
  }),
  methods: {
    openDialog() {
      this.tictacDialog = true;
    },
    clickHere(val) {
      if (this.yourToken == "") {
        return;
      }
      setTimeout(() => {
        this.computerTurn();
      }, 2500);
      if (val == 1) {
        if (this.exes1 == "") {
          this.yourListedNumber.push(val);

          return (this.exes1 = this.yourToken);
        }
      }
      if (val == 2) {
        if (this.exes2 == "") {
          this.yourListedNumber.push(val);
          return (this.exes2 = this.yourToken);
        }
      }
      if (val == 3) {
        if (this.exes3 == "") {
          this.yourListedNumber.push(val);
          return (this.exes3 = this.yourToken);
        }
      }
      if (val == 4) {
        if (this.exes4 == "") {
          this.yourListedNumber.push(val);
          return (this.exes4 = this.yourToken);
        }
      }
      if (val == 5) {
        if (this.exes5 == "") {
          this.yourListedNumber.push(val);
          return (this.exes5 = this.yourToken);
        }
      }
      if (val == 6) {
        if (this.exes6 == "") {
          this.yourListedNumber.push(val);
          return (this.exes6 = this.yourToken);
        }
      }
      if (val == 7) {
        if (this.exes7 == "") {
          this.yourListedNumber.push(val);
          return (this.exes7 = this.yourToken);
        }
      }
      if (val == 8) {
        if (this.exes8 == "") {
          this.yourListedNumber.push(val);
          return (this.exes8 = this.yourToken);
        }
      }
      if (val == 9) {
        if (this.exes9 == "") {
          this.yourListedNumber.push(val);
          return (this.exes9 = this.yourToken);
        }
      }

      this.$forceUpdate();
    },
    tokenPicked(val) {
      this.yourToken = val;
      this.yourToken == "X"
        ? (this.userIcon = "mdi-close-outline")
        : (this.userIcon = "mdi-circle-outline");
      this.computerToken = val == "X" ? "O" : "X";
      this.computerTurn();
      this.gameTimer();
    },
    gameTimer() {
      setTimeout(() => {
        this.timerSec -= 1;
        if (this.timerSec == 0) {
          this.timerSec = 59;
          this.timerMin -= 1;
        }
        if (this.timerMin == 0 && this.timerSec == 0) {
          return clearTimeout(this.gameTimer());
        }
        this.gameTimer();
      }, 1000);
    },
    computerTurn() {
      let arr = this.listedNumber.sort();
      console.log(arr);
    },
  },
};
</script>
<style scoped>
.table {
  border-top: double;
  border-bottom: double;
  border-right: double;
  border-left: double;
}
.tr {
  border: 1px solid;
}
.v-simple-table {
  border: 1px solid;
}
</style>
