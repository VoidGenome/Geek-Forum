<template>
  <div id="app">
    <v-dialog v-model="dialog" width="300px" height="350px">
      <v-card width="300px" height="350px">
        <v-card-title class="justify-center">Tic Tac Toe</v-card-title>
        <v-card-text>
          <div class="board">
            <div class="row" v-for="(row, rowIndex) in board" :key="rowIndex">
              <div
                class="square"
                v-for="(square, columnIndex) in row"
                @click="player == 'X' ? makeMove(rowIndex, columnIndex) : ''"
                :key="'A' + columnIndex"
              >
                {{ square }}
              </div>
            </div>
          </div>
          <div class="status">{{ status }}</div>
          <br />
          <v-btn text outlined @click="reset()">Reset</v-btn>
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>
<script>
export default {
  data: () => ({
    board: [
      ["", "", ""],
      ["", "", ""],
      ["", "", ""],
    ],
    player: "X",
    status: "X's turn",
    dialog: false,
  }),

  methods: {
    openDialog() {
      this.dialog = true;
    },
    reset() {
      this.board = [
        ["", "", ""],
        ["", "", ""],
        ["", "", ""],
      ];
      this.player = "X";
      this.status = "X's turn";
    },
    makeMove(row, col) {
      if (this.board[row][col] === "") {
        this.$set(this.board[row], col, this.player);

        if (this.checkWin()) {
          return (this.status = this.player + " wins!");
        } else if (this.checkTie()) {
          return (this.status = "It's a tie!");
        }
        if (this.player == "X") {
          setTimeout(() => {
            this.computerTurn();
          }, 2000);
        }
        this.player = this.player === "X" ? "O" : "X";
        this.status = this.player + "'s turn";
      }
    },
    checkWin() {
      const board = this.board;
      for (let i = 0; i < 3; i++) {
        if (
          board[i][0] !== "" &&
          board[i][0] === board[i][1] &&
          board[i][1] === board[i][2]
        ) {
          return true;
        }
        if (
          board[0][i] !== "" &&
          board[0][i] === board[1][i] &&
          board[1][i] === board[2][i]
        ) {
          return true;
        }
      }
      if (
        board[0][0] !== "" &&
        board[0][0] === board[1][1] &&
        board[1][1] === board[2][2]
      ) {
        return true;
      }
      if (
        board[0][2] !== "" &&
        board[0][2] === board[1][1] &&
        board[1][1] === board[2][0]
      ) {
        return true;
      }
      return false;
    },
    checkTie() {
      for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
          if (this.board[i][j] === "") {
            return false;
          }
        }
      }
      return true;
    },

    computerTurn() {
      let combinations = [
        [1, 2, 3],
        [1, 4, 7],
        [1, 5, 9],
        [2, 5, 8],
        [3, 6, 9],
        [3, 5, 7],
      ];
      let count = 0;
      let countList = [];
      console.log(combinations);
      for (let x in this.board) {
        for (let y in this.board[x]) {
          count = count + 1;
          if (this.board[x][y]) {
            countList.push([count, this.board[x][y]]);
          }
          //   if (!this.board[x][y]) {
          //     return this.computerMove(x, y);
          //   }
        }
      }
      let xlist = [];
      let olist = [];
      for (let w in countList) {
        if (countList[w][1] == "X") {
          xlist.push(countList[w][0]);

          console.log(xlist);
        }
        if (countList[w][1] == "O") {
          olist.push(countList[w][0]);
          console.log(olist);
        }
      }
      let possibleCombinationX = [];
      let possibleCombinationO = [];
      for (let u in xlist) {
        possibleCombinationX = [];
        for (let x in combinations) {
          for (let y in combinations[x]) {
            if (
              combinations[x][y] == xlist[u]
              //  &&
              // !olist.includes(combinations[x][y])
            ) {
              possibleCombinationX.push(combinations[x]);
            }
          }
        }
      }
      for (let u in olist) {
        possibleCombinationO = [];
        for (let x in combinations) {
          for (let y in combinations[x]) {
            if (
              combinations[x][y] == olist[u] &&
              !xlist.includes(combinations[x][y])
            ) {
              possibleCombinationO.push(combinations[x]);
            }
          }
        }
      }
      let possibleMoveX = [];
      console.log(xlist);

      for (let m in possibleCombinationX) {
        for (let y in possibleCombinationX[m]) {
          for (let n in xlist) {
            possibleCombinationO = possibleCombinationO.filter(
              (el) => !el.includes(xlist[n])
            );

            if (
              xlist[n] != possibleCombinationX[m][y] &&
              !possibleMoveX.includes(possibleCombinationX[m][y]) &&
              !xlist.includes(possibleCombinationX[m][y]) &&
              !olist.includes(possibleCombinationX[m][y])
            ) {
              possibleMoveX.push(possibleCombinationX[m][y]);
            }
          }
        }
      }
      const randomIndex = Math.floor(Math.random() * possibleMoveX.length);

      // get random item
      const Xmove = possibleMoveX[randomIndex];
      let countRow = "";
      let countCol = "";
      let countIndex = 0;
      for (let x in this.board) {
        countRow = x;
        for (let y in this.board[x]) {
          countIndex++;
          countCol = y;
          if (countIndex == Xmove) {
            return this.computerMove(countRow, countCol);
          }
        }
      }
    },
    computerMove(row, col) {
      if (this.board[row][col] === "") {
        this.$set(this.board[row], col, this.player);

        if (this.checkWin()) {
          this.status = this.player + " wins!";
          return;
        } else if (this.checkTie()) {
          this.status = "It's a tie!";
          return;
        } else {
          this.player = this.player === "X" ? "O" : "X";
          this.status = this.player + "'s turn";
        }
      }
    },
  },
};
</script>
<style scoped>
.board {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.row {
  display: flex;
}

.square {
  width: 50px;
  height: 50px;
  border: 1px solid black;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
  cursor: pointer;
  user-select: none;
  margin: 5px;
}

.status {
  margin-top: 20px;
  font-size: 18px;
}
</style>
