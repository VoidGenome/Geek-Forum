<template>
  <div>
    <v-card height='700px' class='mr-2'>
      <v-card-text></v-card-text>
    </v-card>
  </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
