<template>
  <div>
    <v-dialog
      content-class="elevation-0"
      class="roundCorner"
      v-model="dialog"
      width="700px"
      height="700px"
    >
      <v-card
        class="roundCorner"
        width="700px"
        height="700px"
        color="blue-grey lighten-5"
      >
        <v-card-title class="justify-center">
          <!-- <div class="text-center"> -->
          Please Login or Signup to continue
          <!-- </div> -->
          <v-btn fab absolute right dark @click="dialog = false"
            ><v-icon large>mdi-close-outline</v-icon></v-btn
          >
        </v-card-title>
        <v-card-text>
          <v-tabs v-model="tabs" centered>
            <v-tab href="#login">Login</v-tab>
            <v-tab href="#signup">SignUp</v-tab>
          </v-tabs>

          <div class="text-center">
            <v-tabs-items v-model="tabs">
              <v-tab-item :value="'login'" style="height: auto">
                <Login ref="login" />
              </v-tab-item>
              <v-tab-item :value="'signup'" style="height: auto">
                <SignUp @goToLogin="goToLogin" ref="signup" />
              </v-tab-item>
            </v-tabs-items>
          </div>
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>
<script>
import Login from "./Login.vue";
import SignUp from "./Register.vue";
import store from "@/store";
export default {
  components: {
    Login,
    SignUp,
  },
  data: () => ({
    dialog: false,
    tabs: "",
    userData: store.state.loggedInUser,
  }),
  created() {
    setTimeout(() => {
      this.dialog = true;
    }, 6000);
  },
  methods: {
    openDialog() {
      this.dialog = true;
    },
    goToLogin(val) {
      if (val == 1) this.tabs = "login";
    },
  },
};
</script>
<style scoped>
.roundCorner {
  border-radius: 50px;
}
</style>
