<template>
  <div>
    <v-dialog
      persistent
      height="700px"
      no-click-animation
      width="400px"
      hide-overlay
      v-model="messageDialog"
      content-class="my-custom-dialog"
      eager
      ref="messageDialog"
    >
      <v-card height="700px" width="400px" color="blue-grey lighten-4">
        <v-card-title
          >Messages<v-spacer /><v-icon @click="messageDialog = false"
            >mdi-close</v-icon
          ></v-card-title
        >
        <v-divider />
        <v-card-text>
          <v-row>
            <v-col cols="2">
              <v-avatar><v-img src="../../../public/chad.jpg" /></v-avatar>
            </v-col>
            <v-col cols="8">
              <span style="font-weight: bold"> Adams Apple</span><br />
              <span>Mangga</span>
            </v-col>
            <v-col cols="2">
              <v-icon role="button">mdi-chat-outline</v-icon>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="2">
              <v-avatar><v-img src="../../../public/chad.jpg" /></v-avatar>
            </v-col>
            <v-col cols="8">
              <span style="font-weight: bold"> Adams Apple</span><br />
              <span>Mangga</span>
            </v-col>
            <v-col cols="2">
              <v-icon role="button">mdi-chat-outline</v-icon>
            </v-col>
          </v-row>
          <v-sheet style="background: #ceeeff"></v-sheet>
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>
<script>
export default {
  data: () => ({
    messageDialog: false,
  }),
  methods: {
    openMessageDialog() {
      this.messageDialog = true;
    },
  },
};
</script>
<style scoped>
.my-custom-dialog >>> {
  align-self: flex-end;
}
.v-dialog {
  position: absolute;
  bottom: 0;
  right: 0;
}
.v-dialog__content {
  align-items: flex-end;
  justify-content: flex-end;
}
</style>
