import Vue from "vue";
import Vuex from "vuex";
import createPersistedState from "vuex-persistedstate";

Vue.use(Vuex);
// const persistedData = new createPersistedState({
//   key: "test",
//   storage: localStorage,
//   reducer: (state) => ({
//     loggedInUser: state.loggedInUser,
//   }),
// });

export default new Vuex.Store({
  plugins: [createPersistedState()],
  state: {
    message: "Hello World!",
    users: [
      { username: "admin", password: "admin" },
      { username: "123", password: "123" },
    ],
    loggedInUser: null,
  },
  mutations: {
    HELLO: (state, payload) => {
      state.message = "Hello" + payload;
    },
    STORE_USER: (state, payload) => {
      state.loggedInUser = payload;
      
    },
    ADD_USER: (state, payload) => {
      state.users.push(payload);
    },
  },
  actions: {
    STORE_USER({ commit }, payload) {
      commit("STORE_USER", payload);
    },
  },

  getters: {},
  modules: {},
  // plugins: [persistedData],
});
