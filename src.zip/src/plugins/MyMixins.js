import { mapState, mapMutations } from "vuex";

const myMixins = {
  install(Vue) {
    Vue.mixin({
      data: () => ({
        test: "",
      }),
      computed: {
        ...mapState(["users", "message", "products"]),
      },
      methods: {
        ...mapMutations([
          "STORE_USER",
          "ADD_USER",
          "PRODUCTS",
          "UPDATE_PRODUCTS",
        ]),
      },
    });
  },
};
export default myMixins;
