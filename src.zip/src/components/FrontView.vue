<template>
  <div>
    <v-container class="d-flex justify-center" style="margin-top: 20vh">
      <v-card width="400px" height="270px" class="backGround">
        <v-card-text>
          <br />
          <br />
          <v-btn block>Play</v-btn>
          <br />
          <v-btn block>Instructions</v-btn>
          <br />
          <v-btn @click="openCanvas()" block>Canvas</v-btn>
          <br />
        </v-card-text>
      </v-card>
    </v-container>
    <v-dialog v-model="dialog" width="400px" height="400px">
      <v-card ref="form" width="400px" height="400px">
        <v-card-text>
          <v-text-field
            ref="city"
            v-model="city"
            :rules="[() => !!city || 'This field is required']"
            outlined
            dense
          ></v-text-field>
          <v-text-field
            ref="region"
            v-model="region"
            :rules="[() => !!region || 'This field is required']"
            outlined
            dense
          ></v-text-field>
          <v-text-field
            ref="country"
            v-model="country"
            :rules="[() => !!country || 'This field is required']"
            outlined
            dense
          ></v-text-field>
          <v-text-field
            ref="age"
            v-model="age"
            :rules="[() => !!age || 'This field is required']"
            outlined
            dense
          ></v-text-field>
        </v-card-text>
        <v-btn @click="submit()" right>Submit</v-btn>
      </v-card>
    </v-dialog>
  </div>
</template>
<script>
export default {
  data: () => ({
    dialog: false,
    city: "",
    region: "",
    country: "",
    age: "",
    formHasErrors: false,
  }),
  computed: {
    form() {
      return {
        city: this.city,
        region: this.region,
        age: this.age,
        country: this.country,
      };
    },
  },
  methods: {
    openCanvas() {
      this.dialog = true;
    },
    submit() {
      this.formHasErrors = false;

      Object.keys(this.form).forEach((f) => {
        this.$refs[f].validate(true);
      });
    },
  },
};
</script>
<style scoped>
/* .backGround {
  background-image: linear-gradient(
    to right bottom,
    #baf6f2,
    #abf5f0,
    #9bf4ee,
    #8af3ec,
    #77f2e9,
    #6ceee4,
    #5fe9e0,
    #52e5db,
    #4dddd3,
    #49d4cb,
    #44ccc3,
    #40c4bb
  );
} */
</style>
