<template>
  <v-app :class="CurrentRoutes != 'Login' ? 'backG' : ''">
    <v-app-bar app class="groundG" dark v-if="CurrentRoutes != 'Login'">
      <v-spacer />
      <!-- <img src="../public/wiggle-peter-griffin.gif" /> -->
      <v-row>
        <v-col cols="9"> </v-col>
        <v-col cols="1" class="mt-3">
          <span v-if="!userData" @click="openSignIn()" role="button"
            >Sign in <LoginRegister ref="signin" /></span
        ></v-col>
        <v-col cols="2">
          <div>
            <v-list-item-content>
              <v-menu offset-y>
                <template v-slot:activator="{ on, attrs }">
                  <v-list-item-title
                    style="color: black"
                    v-bind="attrs"
                    v-on="on"
                    >{{
                      ` ${
                        CurrentRoutes != "Login" && userData
                          ? userData.username
                          : "Guest"
                      }   `
                    }}<v-icon>mdi-account-outline</v-icon></v-list-item-title
                  >
                </template>
                <v-list class="text-center pa-0" v-if="userData">
                  <v-list-item
                    style="cursor: pointer"
                    @click="userData ? ConfirmLogout() : ''"
                  >
                    <v-list-item-title color="red" style="font-weight: bold">
                      <v-icon color="red">mdi-logout-variant</v-icon>
                      Logout</v-list-item-title
                    >
                  </v-list-item>
                </v-list>
              </v-menu>
            </v-list-item-content>
          </div>
        </v-col>
      </v-row>
    </v-app-bar>

    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script>
import store from "@/store";
import LoginRegister from "./views/LoginRegister.vue";
export default {
  name: "App",
  components: {
    LoginRegister,
  },

  data: () => ({
    userData: store.state.loggedInUser,
    // userName :store.state.loggedInUser.username,
  }),
  methods: {
    ConfirmLogout() {
      localStorage.clear();
      this.$router.push(`/`).catch((error) => {
        console.info(error.message);
      });
      window.open(`http://${window.location.host}/`, "_self");
    },

    openSignIn() {
      this.$refs.signin.openDialog();
    },
  },
  computed: {
    CurrentRoutes() {
      if (this.$route.name) {
        return this.$route.name;
      } else return "";
    },
  },
};
</script>
<style scoped>
.backG {
  background-image: linear-gradient(
    to right bottom,
    #baf6f2,
    #abf5f0,
    #9bf4ee,
    #8af3ec,
    #77f2e9,
    #6ceee4,
    #5fe9e0,
    #52e5db,
    #4dddd3,
    #49d4cb,
    #44ccc3,
    #40c4bb
  );
}
.groundG {
  background-image: linear-gradient(
    to right,
    #baf6f2,
    #abf5f0,
    #9bf4ee,
    #8af3ec,
    #77f2e9,
    #6ceee4,
    #5fe9e0,
    #52e5db,
    #4dddd3,
    #49d4cb,
    #44ccc3,
    #40c4bb
  );
}
</style>
