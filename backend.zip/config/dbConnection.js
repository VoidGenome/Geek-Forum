const mysql = require("mysql");

exports.Msconnect = () => {
  const connection = mysql.createPool({
    connectionLimit: 1000,
    connectTimeout: 60 * 60 * 1000,
    acquireTimeout: 60 * 60 * 1000,
    timeout: 60 * 60 * 1000,
    host: "localhost",
    user: "root",
    password: "",
    database: "sample",
    port: 3306,
    debug: false,
    multipleStatements: true,
  });

  return connection;
};

exports.connect = () => {
  const connection = require("knex")({
    client: "mysql",
    version: "5.7",
    // 10.169.130.87
    connection: {
      host: "localhost",
      user: "root",
      password: "",
      database: "sample",
    },
    options: {
      port: 3306,
    },
    pool: { min: 1, max: 10 },
  });
  return connection;
};
