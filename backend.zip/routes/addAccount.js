const express = require("express");
const router = express.Router();
const dbConnect = require("../config/dbConnection");

router.post("/addAccount", async (req, res) => {
  const data = req.body.data;
  const conn = dbConnect.connect();
  const query = await conn("useraccount").insert(data);
  await conn.destroy();
  Promise.resolve(query)
    .then((result) => res.send(result))
    .catch((err) => console.log(err));
  // const data = req.body.data;
  // const conn = dbConnect.Msconnect();
  // conn.query(
  //   `SELECT CustomerCode FROM constructiondates WHERE CustomerCode IN ('${data}')`,
  //   (err, result) => {
  //     conn.end();
  //     if (err) console.log(err);
  //     else res.send(result);
  //   }
  // );
});

router.get("/checkAccount/:username/:password", async (req, res) => {
  const username = req.params.username;
  const password = req.params.password;
  const conn = dbConnect.connect();
  console.log(username);
  const query = await conn
    .select("*")
    .from("useraccount")
    .where("Username", username)
    .where("Password", password);
  await conn.destroy();
  Promise.resolve(query)
    .then((result) => res.send(result))
    .catch((err) => console.log(err));
});

module.exports = router;
